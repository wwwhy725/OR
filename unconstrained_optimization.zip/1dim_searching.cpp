#include <iostream>
#include <vector>
#include<Windows.h>
#include"Function.h"
#include"Exercise.h"
using namespace std;

int main()
{
    exercise_1();

    system("pause");
	return 0;
}