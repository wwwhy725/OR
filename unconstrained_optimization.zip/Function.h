#pragma once
#include<iostream>
#include<vector>
#include<iomanip>
using namespace std;

bool mat_match(const vector<vector<double>> &A, const vector<vector<double>> &B);//check两个矩阵是否一样

vector<vector<double>> mat_mult(const vector<vector<double>> &A, const vector<vector<double>> &B);//矩阵乘法

vector<vector<double>> mat_plus(const vector<vector<double>> &A, const vector<vector<double>> &B);

vector<vector<double>> mat_minus(const vector<vector<double>> &A,const vector<vector<double>> &B);//矩阵减法

void cout_mat(const vector<vector<double>> &A);//输出矩阵

vector<vector<double>> zeros_mat(int m, int n);//创建m行n列的0矩阵

vector<vector<double>> identity_mat(int n);//创建n*n的单位阵

vector<vector<double>> transpose(const vector<vector<double>> &A);//矩阵转置

void LU_Decomposition(vector<vector<double>> &A);//LU分解

vector<vector<double>> get_L(const vector<vector<double>> &A);//获取LU分解后的L

vector<vector<double>> get_U(const vector<vector<double>> &A);//获取LU分解后的U

void row_swap(vector<vector<double>> &A, int i, int j);//交换A的i行和j行

void col_swap(vector<vector<double>> &A, int i, int j);//交换A的i列和j列

void mat_max(const vector<vector<double>> &A, int &p, int &q, int init);//从第init行、列开始的分块矩阵元素绝对值最大值

void mat_max_col(const vector<vector<double>> &A, int &p, int init);//从init列开始的右下角方阵中元素的绝对值最大值

void for_subs(const vector<vector<double>> &L, vector<vector<double>> &b);//前代法

void back_subs(const vector<vector<double>> &U, vector<vector<double>> &y);//回代法

void full_pivot_gaussian_elim(vector<vector<double>> &A, vector<double> &u, vector<double> &v);//全主元高斯消去

void col_pivot_gaussian_elim(vector<vector<double>> &A, vector<double> &u);//列主元高斯消去

vector<vector<double>> LU_solve(vector<vector<double>> &A, vector<vector<double>> &b);//用LU分解解方程

vector<vector<double>> full_pivot_solve(vector<vector<double>> &A, vector<vector<double>> &b);//用全主元高斯消去解方程

vector<vector<double>> col_pivot_solve(vector<vector<double>> &A, vector<vector<double>> &b);//用列主元高斯消去法解方程

void Cholesky(vector<vector<double>> &A, vector<vector<double>> &L);//Cholesky分解

void modified_Cholesky(vector<vector<double>> &A, vector<vector<double>> &D, vector<vector<double>> &L);//改进平方根法

vector<vector<double>> Cholesky_sol(vector<vector<double>> &A, vector<vector<double>> &b);//平方根法解方程

vector<vector<double>> modified_Cholesky_sol(vector<vector<double>> &A, vector<vector<double>> &b);//改进平方根法解方程

vector<vector<double>> create_hilbert(int n);  //生成n阶hilbert矩阵

double vec_norm_2(const vector<vector<double>> &A, const vector<vector<double>> &B);  //A和B都是n行1列的

double vec_norm_1(const vector<vector<double>> &A);  //A是n行1列的

vector<vector<double>> sign(const vector<vector<double>> &w);  //w向量的各位置符号

double vec_norm_inf(const vector<vector<double>> &v, int &posi);  //向量无穷范数，posi放最大分量的位置

double esti_mat_norm1(const vector<vector<double>> &B);

double mat_norm_inf(const vector<vector<double>> &A);  //矩阵无穷范数

double kay_inf(const vector<vector<double>> &A);  //计算无穷范数条件数

void Householder(const vector<vector<double>> &x, vector<vector<double>> &v, double &beita);  //v送进去和x一样规模(先取0向量)

vector<vector<double>> House_mat(const vector<vector<double>> &v, double beta);

vector<vector<double>> mat_partition(const vector<vector<double>> &A, int m1, int m2, int n1, int n2);  //提取第m1~m2行，n1~n2列

vector<vector<double>> QR_solve(vector<vector<double>> &A, vector<vector<double>> &b);

void QR(vector<vector<double>> &A, vector<vector<double>> &d);

vector<vector<double>> LS(vector<vector<double>> &A, vector<vector<double>> &b, double &error);

void Jacobi(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x);

void G_S(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x);

void SOR(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x, double &w);

void new_Jacobi(vector<vector<double>> &U, int n);

void new_G_S(vector<vector<double>> &U, int n);

void new_SOR(vector<vector<double>> &U, int n, double w);

void conj_grad(const vector<vector<double>> &A, const vector<vector<double>> &b, vector<vector<double>> &x);

void upper_Hessenberg(vector<vector<double>> &A);

vector<vector<double>> double_step_displacement_qr(vector<vector<double>> &H);//n > 2 的情况

int irreducible_uppper_Hessenberg(const vector<vector<double>> &H);  //不可约上Hessenberg

int almost_upper_trimax(const vector<vector<double>> &H);  //拟上三角

void convergence_determination(vector<vector<double>> &H, int &m, int &l);  //收敛性判断

void implicit_qr(vector<vector<double>> &A);

void cal_eigen(const vector<vector<double>> &A, double &a, double &b);

void eigenvalue(vector<vector<double>> &A);

double power_method(const vector<vector<double>> &A, int times);

double find_largest_root(const vector<double> &a, int times);//a放系数(从左到右为次数升高顺序)，times放次数

double E_norm(vector<vector<double>> &A);

double sgn(double x);

void Jacobi_pq(vector<vector<double>> &A, vector<vector<double>> &J, int p, int q);//对A的p和q做jacobi，返回jacobi变换矩阵

void Pass_Jacobi(vector<vector<double>> &A, vector<vector<double>> &eigenvectors);

void quickSort(vector<double> &a, int low ,int high);

void eigen_of_tri_diag(vector<vector<double>> &A);

int number_of_sign_change(const vector<vector<double>> &T, double mu);//T是实对称三对角

double dichotomy(const vector<vector<double>> &T, int m);//矩阵T的第m个特征值

vector<vector<double>> reverse_power_method(const vector<vector<double>> &T, double lambda);//lambda是特征值的近似值

void dichotomy_and_reverse_power(const vector<vector<double>> &T);

void bi_diag(vector<vector<double>> &A, vector<vector<double>> &U, vector<vector<double>> &V);

void wilkinson_SVD(vector<vector<double>> &B, vector<vector<double>> &P, vector<vector<double>> &Q);

void convergence_svd(vector<vector<double>> &A, int &p, int &q);//p=n,q=0传进去

void B_2_2(vector<vector<double>> &B, vector<vector<double>> &G, int k);//G存储givens变换,j是对角0的位置

void ep_eq_et(double &ep, double &eq, double &et, const vector<vector<double>> &U, const vector<vector<double>> &V, const vector<vector<double>> &A, const vector<vector<double>> &A1);

void SVD(vector<vector<double>> &A);

//以上是旧时代的残党

void scalar_times_mat(const double &a, vector<vector<double>> &A);

double three_hump_camel(const double &x1, const double &x2);//THREE-HUMP CAMEL FUNCTION

double f2(const double &x1, const double &x2);  //Rosenbrock function

double f3(const double &x1, const double &x2, const double &x3);

double f4(const double &x1, const double &x2, const double &x3, const double &x4);

double f5(const double &x1, const double &x2, const double &x3, const double &x4, const double &x5);

vector<vector<double>> gradf(const double &x1, const double &x2);//gradient of three-hump camel function

vector<vector<double>> gradf2(const double &x1, const double &x2);  //gradient of f

vector<vector<double>> gradf3(const double &x1, const double &x2, const double &x3);

vector<vector<double>> gradf4(const double &x1, const double &x2, const double &x3, const double &x4);

vector<vector<double>> gradf5(const double &x1, const double &x2, const double &x3, const double &x4, const double &x5);

double phi(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

double phi_(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);  //phi'

double phif(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

double phi_f(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

double wolfe_powell_find_alpha(const vector<vector<double>> &x, const vector<vector<double>> &d);

double wolfe_powell_find_alpha_f(const vector<vector<double>> &x, const vector<vector<double>> &d);

void DFP(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

void DFP_f(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

void BFGS(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

void BFGS_f(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d);

void wolfe_powell_quasi_newton(int choice, int n);

void wolfe_powell_quasi_newton_f(int choice);
