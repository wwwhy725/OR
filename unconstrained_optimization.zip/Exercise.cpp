#include "Exercise.h"
#include<ctime>
#include<cstdlib>
#include<windows.h>
#include<chrono>
#include<cmath>
#include<iomanip>


void exercise_1()//一维非精确搜索wolfe-powell准则
{  
    int choice, n, m, flag;
    while(flag)
    {
        cout << "choose your method: " << endl;
        cout << "1 refers to Wolfe-Powell +  DFP" << endl;
        cout << "2 refers to Wolfe-Powell +  BFGS" << endl;
        cin >> choice;
        cout << "choose your test function: " << endl;
        cout << "1 refers to Rosenbrock function" << endl;
        cout << "2 refers to three-hump camel function" << endl;
        cin >> m;
        if(m == 1)
        {
            cout << "choose the order of Rosenbrock function from 2 to 5: " << endl;
            cin >> n;
            wolfe_powell_quasi_newton(choice, n);
        }
        else if (m == 2)
        {
            wolfe_powell_quasi_newton_f(choice);
        }
        cout << "exit or not? 1 -> continue and 0 -> exit" << endl;
        cin >> flag;
    }
}
    
