#pragma once
#include <iostream>
#include <vector>
#include<Windows.h>
#include"Function.h"
#include<stdlib.h>
#include <time.h>
#include<iomanip>


void exercise_1();
