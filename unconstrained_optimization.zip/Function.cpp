#include<cmath>
#include<iomanip>
#include"Function.h"
#include<chrono>
#include<windows.h>
#include<ctime>
#include<iomanip>
using namespace std;

bool mat_match(const vector<vector<double>> &A, const vector<vector<double>> &B)
{
    int m1 = A.size(), m2 = B.size();
    int n1 = A[0].size(), n2 = B[0].size();
    if(m1 != m2 or n1 != n2)
    {
        cout << "矩阵大小不匹配" << endl;
        return false;
    }
    else
    {
        for(int i = 0;i < m1;i++)
        {
            for(int j = 0;j < n1;j++)
            {
                if(A[i][j] != B[i][j])
                {
                    cout << "矩阵某位置对应不相等" << endl;
                    return false;
                }
            }
        }
        return true;
    }
}

vector<vector<double>> mat_mult(const vector<vector<double>> &A, const vector<vector<double>> &B)
{
    vector<vector<double>> temp;
    vector<double> array;
    int n = A[0].size();
    int m = B.size();
    if(n != m)
    {
        cout << "mat_mult wrong" << endl;
        return temp;
    }
    else
    {
        for(int i = 0;i < A.size();i++)
        {
            for(int j = 0;j < B[0].size();j++)
            {
                double sum = 0.0;
                for(int k = 0;k < n;k++)
                {
                    sum += A[i][k] * B[k][j];
                }
                array.push_back(sum);
            }
            temp.push_back(array);
            array.erase(array.begin(), array.end());
        }
    }
    return temp;
}

vector<vector<double>> mat_plus(const vector<vector<double>> &A, const vector<vector<double>> &B)
{
    if(A.size() == B.size() and A[0].size() == B[0].size())
    {
        vector<vector<double>> C = zeros_mat(A.size(), A[0].size());
        for(int i = 0;i < A.size();i++) for(int j = 0;j < A[0].size();j++) C[i][j] = A[i][j] + B[i][j];
        return C;
    }
    else
    {
        cout << "mat_plus wrong" << endl;
        return zeros_mat(A.size(), A[0].size());
    }
}

vector<vector<double>> mat_minus(const vector<vector<double>> &A,const vector<vector<double>> &B)
{
    if(A.size() == B.size() and A[0].size() == B[0].size())
    {
        vector<vector<double>> C = zeros_mat(A.size(), A[0].size());
        for(int i = 0;i < A.size();i++) for(int j = 0;j < A[0].size();j++) C[i][j] = A[i][j] - B[i][j];
        return C;
    }
    else
    {
        cout << "mat_minus wrong" << endl;
        return zeros_mat(A.size(), A[0].size());
    }
}

void cout_mat(const vector<vector<double>> &A)  //输出矩阵 如果是n行1列的以行向量形式输出
{
    int m = A.size();
    int n = A[0].size();
    if(n == 1)
    {
        for(int i = 0;i < m;i++) cout << A[i][0] << " ";
    }
    else
    {
        for(int i = 0;i < m;i++)
        {
            for(int j = 0;j < n;j++)
            {
                cout << A[i][j] << " ";
            }
            cout << endl;
        }
    }
    cout << endl;
}

vector<vector<double>> zeros_mat(int m, int n)  //创建m行n列的0矩阵
{
    vector<vector<double>> temp(m, vector<double>(n, 0));
    return temp;
}

vector<vector<double>> identity_mat(int n)  //n*n的单位阵
{
    vector<vector<double>> I;
    for(int i = 0;i < n;i++)
    {
        vector<double> temp(n, 0);
        temp[i] = 1;
        I.push_back(temp);
    }
    return I;
}

vector<vector<double>> transpose(const vector<vector<double>> &A)  //转置
{
    int m = A.size(), n = A[0].size();
    if(n == 1)
    {
        //cout << "转置之后变成1行n列的向量, error!" << endl;
        vector<vector<double>> B = zeros_mat(n, m);
        for(int i = 0;i < m;i++) B[0][i] = A[i][0];
        return B;
    }
    else
    {
        vector<vector<double>> B = zeros_mat(n, m);
        for(int i = 0;i < n;i++)
        {
            for(int j = 0;j < m;j++)
            {
                B[i][j] = A[j][i];
            }
        }
        return B;
    }
}

void LU_Decomposition(vector<vector<double>> &A)  //LU分解
{
    int n = A.size();
    for(int k = 0;k < n-1;k++)
    {
        for(int i = k + 1;i < n;i++)
        {
            A[i][k] /= A[k][k];
        }
        for(int i = k + 1;i < n;i++)
        {
            for(int j = k + 1;j < n;j++)
            {
                A[i][j] -= A[i][k]*A[k][j];
            }
        }
    }
}

vector<vector<double>> get_L(const vector<vector<double>> &A)  //获取LU分解后的L
{
    vector<vector<double>> L;
    int n = A.size();
    for(int i = 0;i < n;i++)
    {
        vector<double> temp;
        for(int j = 0;j < n;j++)  //LU分解直接将L存在A的下三角部分，再补对角线的1即可
        {
            if(j < i) temp.push_back(A[i][j]);
            else if(j == i) temp.push_back(1);
            else temp.push_back(0);
        }
        L.push_back(temp);
    }
    return L;
}

vector<vector<double>> get_U(const vector<vector<double>> &A)  //获取LU分解后的U
{
    vector<vector<double>> U;
    int n = A.size();
    for(int i = 0;i < n;i++)  //LU分解直接将U存在A的上三角部分
    {
        vector<double> temp;
        for(int j = 0;j < n;j++)
        {
            if(j >= i) temp.push_back(A[i][j]);
            else temp.push_back(0);
        }
        U.push_back(temp);
    }
    return U;
}

void row_swap(vector<vector<double>> &A, int i, int j)  //交换A的i行和j行
{
    int n = A[0].size();
    for(int t = 0;t < n;t++)
    {
        double temp;
        temp = A[i-1][t];A[i-1][t] = A[j-1][t];A[j-1][t] = temp;
    }
}

void col_swap(vector<vector<double>> &A, int i, int j)  //交换A的i列和j列
{
    int m = A.size();
    for(int t = 0;t < m;t++)
    {
        double temp;
        temp = A[t][i-1];A[t][i-1] = A[t][j-1];A[t][j-1] = temp;
    }
}

void mat_max(const vector<vector<double>> &A, int &p, int &q, int init)  //找从第init行、列开始的小块元素的最大值，p和q是最大值的行列
{
    int n = A.size();
    if(n != A[0].size())
    {
        cout << "A要求是方阵" << endl;
        return ;
    }
    double A_max = 0.0;
    for(int i = init-1;i < n;i++)
    {
        for(int j = init-1;j < n;j++)
        {
            if(abs(A[i][j]) >= A_max)
            {
                A_max = A[i][j];
                p = i+1;
                q = j+1;
                //cout << p << q << endl;
            }
        }
    }
}

void mat_max_col(const vector<vector<double>> &A, int &p, int init)  //找第init列的元素最大值，p是最大值的行
{
    int n = A.size();
    if(n != A[0].size())
    {
        cout << "A要求是方阵" << endl;
        return ;
    }
    double A_max = 0.0;
    for(int i = init-1;i < n;i++)
    {
        if(abs(A[i][init-1]) >= A_max)
        {
            A_max = A[i][init-1];
            p = i+1;
        }
    }
}

void for_subs(const vector<vector<double>> &L, vector<vector<double>> &b)  //前代法
{
    int n = b.size();
    for(int i = 0;i < n-1;i++)
    {
        b[i][0] /= L[i][i];
        for(int j = i+1;j < n;j++)
        {
            b[j][0] -= b[i][0] * L[j][i];
        }
    }
    //printf("%d\n",n-1);
    b[n-1][0] /= L[n-1][n-1];
}

void back_subs(const vector<vector<double>> &U, vector<vector<double>> &y)  //回代法
{
    int n = y.size();
    for(int i = n-1;i > 0;--i)
    {
        y[i][0] /= U[i][i];
        for(int j = i-1;j > -1;--j)
        {
            y[j][0] -= y[i][0] * U[j][i];
        }
    }
    y[0][0] /= U[0][0];
}

void full_pivot_gaussian_elim(vector<vector<double>> &A, vector<double> &u, vector<double> &v)  //全主元高斯消去法
{
    int n = A.size();
    int p = 0, q = 0;
    for(int k = 0;k < n-1;k++)
    {
        mat_max(A, p, q, k+1);
        row_swap(A, k+1, p);
        col_swap(A, k+1, q);
        u[k] = p;
        v[k] = q;
        if(A[k][k] != 0)
        {
            for(int i = k+1;i < n;i++)
            {
                A[i][k] /= A[k][k];
                for(int j = k+1;j < n;j++)
                {
                    A[i][j] -= A[i][k]*A[k][j];
                }
            }
        }
        else 
        {
            cout << "矩阵奇异" << endl;
            return ;
        }
    }
}

void col_pivot_gaussian_elim(vector<vector<double>> &A, vector<double> &u)  //列主元高斯消去法
{
    int n = A.size();
    int p = 0;
    for(int k = 0;k < n-1;k++)
    {
        mat_max_col(A, p, k+1);
        row_swap(A, k+1, p);
        u[k] = p;
        if(A[k][k] != 0)
        {
            for(int i = k+1;i < n;i++)
            {
                A[i][k] /= A[k][k];
                for(int j = k+1;j < n;j++)
                {
                    A[i][j] -= A[i][k]*A[k][j];
                }
            }
        }
        else 
        {
            cout << "矩阵奇异" << endl;
            return ;
        }
    }
}

vector<vector<double>> LU_solve(vector<vector<double>> &A, vector<vector<double>> &b)  //用LU分解解方程
{
    int n = A.size();
    LU_Decomposition(A);
    vector<vector<double>> L = get_L(A);
    vector<vector<double>> U = get_U(A);
    for_subs(L, b);
    back_subs(U, b);
    return b;
}

vector<vector<double>> full_pivot_solve(vector<vector<double>> &A, vector<vector<double>> &b)  //用全主元高斯消去法解方程
{
    int n = A.size();
    vector<double> u(n, 0);
    vector<double> v(n, 0);
    full_pivot_gaussian_elim(A, u, v);
    vector<vector<double>> L = get_L(A);
    vector<vector<double>> U = get_U(A);
    vector<vector<double>> P = identity_mat(n);
    vector<vector<double>> Q = identity_mat(n);
    for(int i = 0;i < n-1;i++)  //根据u,v的记录交换P的行和Q的列
    {
        row_swap(P, i+1, u[i]);
        col_swap(Q, i+1, v[i]);
    }
    vector<vector<double>> result = mat_mult(P, b);
    for_subs(L, result);
    //for(int i = 0;i < result.size();i++) cout << result[i][0] << " ";
    back_subs(U, result);
    result = mat_mult(Q, result);
    return result;
}

vector<vector<double>> col_pivot_solve(vector<vector<double>> &A, vector<vector<double>> &b)  //用列主元高斯消去法解方程
{
    int n = A.size();
    vector<double> u(n, 0);
    col_pivot_gaussian_elim(A, u);
    vector<vector<double>> L = get_L(A);
    vector<vector<double>> U = get_U(A);
    vector<vector<double>> P = identity_mat(n);
    for(int i = 0;i < n-1;i++)  //根据u,v的记录交换P的行和Q的列
    {
        row_swap(P, i+1, u[i]);
    }
    vector<vector<double>> result = mat_mult(P, b);
    for_subs(L, result);
    back_subs(U, result);
    return result;
}

void Cholesky(vector<vector<double>> &A, vector<vector<double>> &L)  //Cholesky分解
{
    //L必须未经初始化！！！！！
    if(!mat_match(A,transpose(A)))
    {
        cout << "不是对称阵" << endl;
        return ;
    }
    int n = A.size();
    for(int k = 0;k < n;k++)
    {
        A[k][k] = sqrt(A[k][k]);
        for(int i = k+1;i < n;i++)
        {
            A[i][k] /= A[k][k];
        }
        for(int j = k+1;j < n;j++)
        {
            for(int i = j;i < n;i++)
            {
                A[i][j] -= A[i][k]*A[j][k];
            }
        }
    }
    for(int i = 0;i < n;i++)  //获取分解完的L
    {
        vector<double> temp;
        for(int j = 0;j < n;j++)
        {
            if(j <= i) temp.push_back(A[i][j]);
            else temp.push_back(0);
        }
        L.push_back(temp);
    }
}

void modified_Cholesky(vector<vector<double>> &A, vector<vector<double>> &D, vector<vector<double>> &L)  //改进的平方根法
{
    //L必须没有初始化，D是零矩阵！！！
    int n = A.size();
    vector<double> v(n-1, 0);
    for(int j = 0;j < n;j++)
    {
        for(int i = 0;i < j;i++)
        {
            v[i] = A[j][i]*A[i][i];
        }
        for(int i = 0;i < j;i++)
        {
            A[j][j] -= A[j][i]*v[i];
        }
        for(int i = j+1;i < n;i++)
        {
            double sum = 0;
            for(int t = 0;t < j;t++)
            {
                sum += A[i][t]*v[t];
            }
            A[i][j] = (A[i][j] - sum)/A[j][j];
        }
    }
    for(int i = 0;i < n;i++)  //获取L
    {
        vector<double> temp;
        for(int j = 0;j < n;j++)
        {
            if(j < i) temp.push_back(A[i][j]);
            else if(j == i) temp.push_back(1);
            else temp.push_back(0);
        }
        L.push_back(temp);
    }
    for(int i = 0;i < n;i++)  //获取D（对角线）
    {
        D[i][i] = A[i][i];
    }
}

vector<vector<double>> Cholesky_sol(vector<vector<double>> &A, vector<vector<double>> &b)  //用平方根法解方程
{
    vector<vector<double>> L;
    Cholesky(A, L);
    for_subs(L, b);
    back_subs(transpose(L), b);
    return b;
}

vector<vector<double>> modified_Cholesky_sol(vector<vector<double>> &A, vector<vector<double>> &b)  //用改进的平方根法解方程
{
    int n = A.size();
    vector<vector<double>> L;
    vector<vector<double>> D = zeros_mat(n, n);
    modified_Cholesky(A, D, L);
    for_subs(L, b);
    vector<vector<double>> temp = mat_mult(D, transpose(L));
    back_subs(temp, b);
    return b;
}

vector<vector<double>> create_hilbert(int n)  //生成n阶hilbert矩阵
{
    vector<vector<double>> A = zeros_mat(n, n);
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            A[i][j] = 1.0/(i + j + 1);
        }
    }
    return A;
}

double vec_norm_2(const vector<vector<double>> &A, const vector<vector<double>> &B)
{
    int m = A.size(), n = B.size();
    if(m != n)
    {
        cout << "快爬" << endl;
        return 0.0;
    }
    else
    {
        double sum = 0.0;
        for(int i = 0;i < m;i++)
        {
            sum += (A[i][0] - B[i][0])*(A[i][0] - B[i][0]);
        }
        return sqrt(sum);
    }
}

double vec_norm_1(const vector<vector<double>> &v)  //向量1范数
{
    double sum = 0.0;
    int n = v.size();
    for(int i = 0;i < n;i++)
    {
        sum += abs(v[i][0]);
    }
    return sum;
}

double vec_norm_inf(const vector<vector<double>> &v, int &posi)  //向量无穷范数，posi放最大分量的位置
{
    int n = v.size();
    double Max = abs(v[0][0]);
    for(int i = 1;i < n;i++)
    {
        if(abs(v[i][0]) > Max) {Max = abs(v[i][0]);posi = i+1;}
    }
    return Max;
}

vector<vector<double>> sign(const vector<vector<double>> &w)  //w向量的各位置符号
{
    int n = w.size();
    vector<vector<double>> v = zeros_mat(n, 1);
    for(int i = 0;i < n;i++)
    {
        if(w[i][0] > 0) v[i][0] = 1;
        else if (w[i][0] < 0) v[i][0] = -1;
    }
    return v;
}

double esti_mat_norm1(const vector<vector<double>> &A)
{
    int n = A.size();
    vector<vector<double>> x(n, vector<double>(1, 1.0/n));
    int k = 1, posi = 0;
    double gamma = 0.0;
    vector<vector<double>> w, v, z;
    while (k == 1)
    {
        vector<vector<double>> A1=A, A2=A,B=transpose(A);
        w = col_pivot_solve(B, x);
        v = sign(w);
        z = col_pivot_solve(A2, v);
        if(vec_norm_inf(z, posi) <= mat_mult(transpose(z), x)[0][0])
        {
            gamma = vec_norm_1(w);
            k = 0;
        }
        else
        {
            x = zeros_mat(n, 1);x[posi-1][0] = 1;
            k = 1;
        }
    }
    return gamma;
}

double mat_norm_inf(const vector<vector<double>> &A)  //矩阵无穷范数
{
    int m = A.size(), n = A[0].size();
    double Max = 0.0;
    for(int i = 0;i < m;i++)
    {
        double sum = 0.0;
        for(int j = 0;j < n;j++)
        {
            sum += abs(A[i][j]);
        }
        if(Max <= sum) Max = sum;
    }
    return Max;
}

double kay_inf(const vector<vector<double>> &A)
{
    double gamma1 = esti_mat_norm1(A);
    double gamma2 = mat_norm_inf(A);
    return gamma1*gamma2;
}

void Householder(vector<vector<double>> &x, vector<vector<double>> &v, double &beita)  //v送进去和x一样规模(先取0向量)
{
    int n = x.size();
    int posi = 0;
    double yita = vec_norm_inf(x, posi);
    for(int i = 0;i < n;i++) x[i][0] = x[i][0]/yita;
    double sigma = 0.0;
    for(int i = 1;i < n;i++)
    {
        sigma += x[i][0]*x[i][0];
        v[i][0] = x[i][0];
    }
    if(sigma == 0)
    {
        beita = 0.0;
    }
    else
    {
        double alpha = sqrt(x[0][0]*x[0][0] + sigma);
        if(x[0][0] <= 0)
        {
            v[0][0] = x[0][0] - alpha;
        }
        else
        {
            v[0][0] = (-sigma)/(x[0][0] + alpha);
        }
        beita = 2*v[0][0]*v[0][0]/(sigma + v[0][0]*v[0][0]);
        for(int i = 1;i < n;i++) v[i][0] = v[i][0]/v[0][0];
        v[0][0] = 1;
    }
}

vector<vector<double>> House_mat(const vector<vector<double>> &v, double beta)
{
    int n = v.size();
    vector<vector<double>> a = mat_mult(v, transpose(v));
    for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) a[i][j] *= beta;
    a = mat_minus(identity_mat(n), a);
    return a;
}

vector<vector<double>> mat_partition(const vector<vector<double>> &A, int m1, int m2, int n1, int n2)  //提取第m1~m2行，n1~n2列
{
    vector<vector<double>> temp = zeros_mat(m2-m1+1, n2-n1+1);
    for(int i = m1-1;i < m2;i++)
    {
        for(int j = n1-1;j < n2;j++)
        {
            temp[i-m1+1][j-n1+1] = A[i][j];
        }
    }
    return temp;
}

void QR(vector<vector<double>> &A, vector<vector<double>> &d)
{
    int m = A.size(), n = A[0].size();
    for(int j = 0;j < n;j++)
    {
        if(j < m-1)
        {
            double beita = 0.0;
            vector<vector<double>> v = zeros_mat(m-j, 1), x = zeros_mat(m-j, 1);
            for(int k = 0;k < m-j;k++) x[k][0] = A[k+j][j];
            Householder(x, v, beita);
            vector<vector<double>> temp = mat_partition(A, j+1, m, j+1, n), temp_ = mat_mult(v, transpose(v));
            for(int i = 0;i < temp_.size();i++) for(int k = 0;k < temp_[0].size();k++) temp_[i][k] *= beita;
            vector<vector<double>> H = mat_minus(identity_mat(m-j), temp_);
            temp = mat_mult(H, temp);
            for(int i = 0;i < temp.size();i++) for(int k = 0;k < temp[0].size();k++) A[i+j][k+j] = temp[i][k];
            d[j][0] = beita;
            for(int i = 0;i < m-j-1;i++) A[i+j+1][j] = v[i+1][0];
        }
    }
}

vector<vector<double>> QR_solve(vector<vector<double>> &A, vector<vector<double>> &b)
{
    //先从QR分解中搞出Q和R
    int m = A.size(), n = A[0].size();
    vector<vector<double>> d = zeros_mat(n, 1);
    QR(A, d);
    vector<vector<double>> Q = identity_mat(m);
    vector<vector<double>> R = zeros_mat(n, n);
    for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) if(i <= j) R[i][j] = A[i][j];
    for(int i = 0;i < n;i++)
    {
        vector<vector<double>> v = zeros_mat(m, 1);
        for(int j = 0;j < m;j++)
        {
            if(i == j) v[j][0] = 1;
            else if (i < j)
            {
                v[j][0] = A[j][i];
            }
            else v[j][0] = 0;
        }
        vector<vector<double>> temp = mat_mult(v, transpose(v));
        for(int j = 0;j < temp.size();j++) for(int k = 0;k < temp[0].size();k++) temp[j][k] *= d[i][0];
        Q = mat_mult(mat_minus(identity_mat(m), temp), Q);
    }
    //解方程
    vector<vector<double>> result = mat_mult(Q, b);
    back_subs(R, result);
    return result;
}

vector<vector<double>> LS(vector<vector<double>> &A, vector<vector<double>> &b, double &error)
{
    //先从QR分解中搞出Q和R
    int m = A.size(), n = A[0].size();
    vector<vector<double>> d = zeros_mat(n, 1);
    QR(A, d);
    vector<vector<double>> Q = identity_mat(m);
    vector<vector<double>> R = zeros_mat(n, n);
    for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) if(i <= j) R[i][j] = A[i][j];
    for(int i = 0;i < n;i++)
    {
        vector<vector<double>> v = zeros_mat(m, 1);
        for(int j = 0;j < m;j++)
        {
            if(i == j) v[j][0] = 1;
            else if (i < j)
            {
                v[j][0] = A[j][i];
            }
            else v[j][0] = 0;
        }
        vector<vector<double>> temp = mat_mult(v, transpose(v));
        for(int j = 0;j < temp.size();j++) for(int k = 0;k < temp[0].size();k++) temp[j][k] *= d[i][0];
        Q = mat_mult(Q, mat_minus(identity_mat(m), temp));
    }
    //计算c1 = Q1^T*b
    vector<vector<double>> Q1 = zeros_mat(m, n);
    for(int i = 0;i < m;i++) for(int j = 0;j < n;j++) Q1[i][j] = Q[i][j];
    vector<vector<double>> c1 = mat_mult(transpose(Q1), b);
    //计算误差c2 = Q2^T*b的2范数平方
    vector<vector<double>> Q2 = zeros_mat(m, m-n);
    for(int i = 0;i < m;i++) for(int j = 0;j < m-n;j++) Q2[i][j] = Q[i][j+n];
    vector<vector<double>> c2 = mat_mult(transpose(Q2), b);
    error = vec_norm_2(c2, zeros_mat(c2.size(), 1));
    //求解Rx = c1
    back_subs(R, c1);
    return c1;
}

void Jacobi(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x)
{
    double tol = 1e-7;  //阈值
    int count = 1, N1 = x.size(), posi = 0;  //迭代次数
    vector<vector<double>> y = zeros_mat(N1, 1), error = zeros_mat(N1, 1);
    auto start = chrono::steady_clock::now();
    for(int i = 0;i < N1;i++)
    {
        y[i][0] = 0.0;
        for(int j = 0;j < N1;j++) y[i][0] += B[i][j] * x[j][0];
        y[i][0] += g[i][0];
    }
    while (vec_norm_inf(mat_minus(x, y), posi) > tol)
    {
        x = y;
        for(int i = 0;i < N1;i++)
        {
            y[i][0] = 0.0;
            for(int j = 0;j < N1;j++) y[i][0] += B[i][j] * x[j][0];
            y[i][0] += g[i][0];
        }
        count++;
    }
    auto end = chrono::steady_clock::now();
    cout << "iteration: " << count << "times" << endl;
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
    x = y;
}

void G_S(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x)//这里为了第二问稍微改了一点
{
    double tol = 1e-7;  //阈值
    int count = 0, N2 = x.size(), posi = 0;  //迭代次数
    vector<vector<double>> error = zeros_mat(N2, 1), y = zeros_mat(N2, 1);
    auto start = chrono::steady_clock::now();
    while (vec_norm_inf(mat_minus(x, y), posi) > tol)
    {
        y = x;
        for(int i = 0;i < N2;i++)
        {
            x[i][0] = 0.0;
            for(int j = 0;j < N2;j++) x[i][0] += B[i][j] * x[j][0];
            x[i][0] += g[i][0];
        }
        count++;
    }
    auto end = chrono::steady_clock::now();
    cout << "iteration: " << count << "times" << endl;
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
}

void SOR(const vector<vector<double>> &B, const vector<vector<double>> &g, vector<vector<double>> &x, double &w)
{
    double tol = 1e-7, temp = 0.0;  //阈值
    int count = 0, N = x.size(), posi = 0;  //迭代次数
    vector<vector<double>> error = zeros_mat(N, 1), y = zeros_mat(N, 1);
    auto start = chrono::steady_clock::now();
    while (vec_norm_inf(mat_minus(x, y), posi) > tol)
    {
        y = x;
        for(int i = 0;i < N;i++)
        {
            temp = x[i][0];
            x[i][0] = 0.0;
            for(int j = 0;j < N;j++) x[i][0] += B[i][j] * x[j][0];
            x[i][0] = (1 - w) * temp + w * (x[i][0] + g[i][0]);
        }
        count++;
    }
    auto end = chrono::steady_clock::now();
    cout << "iteration: " << count << "times" << endl;
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
}

void new_Jacobi(vector<vector<double>> &U, int n)
{
    double tol = 1e-7, h = 1.0/n, error = 0;
    int count = 1;
    vector<vector<double>> U1 = U;
    do
    {
        for(int i = 1;i < n;i++)
        {
            for(int j = 1;j < n;j++)
            {
                U1[i][j] = 1/(4+h*h*exp(i*h*j*h))*(U[i-1][j]+U[i][j-1]+U[i+1][j]+U[i][j+1] + h*h*(i*h+j*h));
            }
        }
        error = abs(U[1][1] - U1[1][1]);
        for(int i = 1;i < n;i++) for(int j = 1;j < n;j++) if(abs(U[i][j] - U1[i][j]) > error) error = abs(U[i][j] - U1[i][j]);
        U = U1;
        count++;
    } while (error > tol);
    cout << "iteration: " << count << "times" << endl;
}

void new_G_S(vector<vector<double>> &U, int n)
{
    double tol = 1e-7, h = 1.0/n, error = 0;
    int count = 1;
    vector<vector<double>> U1 = U;
    do
    {
        for(int i = 1;i < n;i++)
        {
            for(int j = 1;j < n;j++)
            {
                U[i][j] = 1/(4+h*h*exp(i*h*j*h))*(U[i-1][j]+U[i][j-1]+U[i+1][j]+U[i][j+1] + h*h*(i*h+j*h));
            }
        }
        error = abs(U[1][1] - U1[1][1]);
        for(int i = 1;i < n;i++) for(int j = 1;j < n;j++) if(abs(U[i][j] - U1[i][j]) > error) error = abs(U[i][j] - U1[i][j]);
        U1 = U;
        count++;
    } while (error > tol);
    cout << "iteration: " << count << "times" << endl;
}

void new_SOR(vector<vector<double>> &U, int n, double w)
{
    double tol = 1e-7, h = 1.0/n, error = 0;
    int count = 1;
    vector<vector<double>> U1 = U;
    do
    {
        for(int i = 1;i < n;i++)
        {
            for(int j = 1;j < n;j++)
            {
                U[i][j] = w*(1/(4+h*h*exp(i*h*j*h))*(U[i-1][j]+U[i][j-1]+U[i+1][j]+U[i][j+1] + h*h*(i*h+j*h))) + (1-w)*U[i][j];
            }
        }
        error = abs(U[1][1] - U1[1][1]);
        for(int i = 1;i < n;i++) for(int j = 1;j < n;j++) if(abs(U[i][j] - U1[i][j]) > error) error = abs(U[i][j] - U1[i][j]);
        U1 = U;
        count++;
    } while (error > tol);
    cout << "iteration: " << count << "times" << endl;
}

void conj_grad(const vector<vector<double>> &A, const vector<vector<double>> &b, vector<vector<double>> &x)  //x传初值进来
{
    int n = x.size(), posi = 0;
    vector<vector<double>> r = mat_minus(b, mat_mult(A, x)), p = zeros_mat(n, 1), r_= zeros_mat(n, 1), p_= zeros_mat(n, 1), temp = zeros_mat(n, 1);
    double k = 0.0, beta, alpha;
    int count = 0;  //计数
    //vector<vector<double>> x_ = zeros_mat(n, 1);
    //x_[1][0] = 1;初始化
    auto start = chrono::steady_clock::now();
    while (vec_norm_inf(r,posi)>1e-7)  //vec_norm_inf(mat_minus(x, x_),posi)>1e-7)
    {
        k++;
        if (k == 1) p = r;
        else
        {
            beta = mat_mult(transpose(r), r)[0][0] / mat_mult(transpose(r_), r_)[0][0];
            for(int i = 0;i < n;i++) p_[i][0] *= beta;
            p = mat_plus(r, p_);
        }
        r_ = r;
        p_ = p;
        alpha = mat_mult(transpose(r), r)[0][0] / mat_mult(transpose(p), mat_mult(A, p))[0][0];
        for(int i = 0;i < n;i++) temp[i][0] = alpha*p[i][0];
        //x_ = x;  用以存储迭代之前的x
        x  = mat_plus(x, temp);
        temp = mat_mult(A, p);
        for(int i = 0;i < n;i++) temp[i][0] *= alpha;
        r = mat_minus(r, temp);
        count++;
    }
    auto end = chrono::steady_clock::now();
    cout << "iteration: " << count << "times" << endl;
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
}

void upper_Hessenberg(vector<vector<double>> &A)
{
    int n = A.size();
    double beta = 0.0;
    vector<vector<double>> v = zeros_mat(n, 1);
    vector<vector<double>> id, temp, partition, partition1, partition2;
    for(int k = 1;k < n-1;k++)
    {
        beta = 0.0;
        v = zeros_mat(n-k, 1);
        id = identity_mat(n-k);
        partition = mat_partition(A, k+1, n, k, k);
        Householder(partition, v, beta);
        temp = mat_mult(v, transpose(v));
        for(int i = 0;i < n-k;i++) for(int j = 0;j < n-k;j++) temp[i][j] *= beta;
        id = mat_minus(id, temp);
        partition1 = mat_mult(id, mat_partition(A, k+1, n, k, n));
        for(int i = k;i < n;i++) for(int j = k-1;j < n;j++) A[i][j] = partition1[i-k][j-k+1];
        partition2 = mat_mult(mat_partition(A, 1, n, k+1, n), id);
        for(int i = 0;i < n;i++) for(int j = k;j < n;j++) A[i][j] = partition2[i][j-k];
    }
}

vector<vector<double>> double_step_displacement_qr(vector<vector<double>> &H)//n > 2 的情况
{
    int n = H.size();
    int m = n - 1;
    double x,y,z,t,s,q,r,beta, u = 1.0e-7;
    vector<vector<double>> v, temp, temp1, temp2, temp3, P = identity_mat(n);
    if(n > 2)
    {
        s = H[m-1][m-1] + H[n-1][n-1];
        t = H[m-1][m-1]*H[n-1][n-1] - H[m-1][n-1]*H[n-1][m-1];
        x = H[0][0]*H[0][0] + H[0][1]*H[1][0] - s*H[0][0] + t;
        y = H[1][0]*(H[0][0]+H[1][1] - s);
        z = H[1][0]*H[2][1];
        for(int k = 0;k < n-2;k++)
        {
            v = zeros_mat(3, 1);
            temp = {{x}, {y}, {z}};
            Householder(temp, v, beta);
            q = max(1,k);
            temp1 = mat_partition(H, k+1, k+3, q, n);
            temp1 = mat_mult(House_mat(v, beta), temp1);//分块拿出来 Householder作用一下
            for(int i = k;i < k+3;i++) for(int j = q-1;j < n;j++) H[i][j] = temp1[i-k][j-q+1];//分块放回去
            r = min(k+4, n);
            temp2 = mat_partition(H, 1, r, k+1, k+3);
            temp2 = mat_mult(temp2, House_mat(v, beta));
            for(int i = 0;i < r;i++) for(int j = k;j < k+3;j++) H[i][j] = temp2[i][j-k];//分块放回去
            x = H[k+1][k];
            y = y = H[k+2][k];
            if(k < n-3) z = H[k+3][k];
            //还要保存P：每个householder都是3x3，所以把单位阵的对应子块拿出来作用一下
            temp3 = mat_partition(P, k+1, k+3, k+1, k+3);
            temp3 = mat_mult(House_mat(v, beta), temp3);
            for(int i = k;i < k+3;i++) for(int j = k;j < k+3;j++) P[i][j] = temp3[i-k][j-k];
        }
        v = zeros_mat(2, 1);
        beta = 0;
        temp = {{x}, {y}};
        Householder(temp, v, beta);
        temp1 = mat_partition(H, n-1, n, n-2, n);
        temp1 = mat_mult(House_mat(v, beta), temp1);
        for(int i = n-2;i < n;i++) for(int j = n-3;j < n;j++) H[i][j] = temp1[i-n+2][j-n+3];
        temp2 = mat_partition(H, 1, n, n-1, n);
        temp2 = mat_mult(temp2, House_mat(v, beta));
        for(int i = 0;i < n;i++) for(int j = n-2;j < n;j++) H[i][j] = temp2[i][j-n+2];
        //最后一个householder是2x2的，所以对最后一个子块作用
        temp3 = mat_partition(P, n-1, n, n-1, n);
        temp3 = mat_mult(House_mat(v, beta), temp3);
        for(int i = n-2;i < n;i++) for(int j = n-2;j < n;j++) P[i][j] = temp3[i-n+2][j-n+2];
        //把很小的值置0
        for(int i = 1;i < n;i++)  //置零
        {
            for(int j = 0;j < i;j++)
            {
                if(abs(H[i][j]) < u) H[i][j] = 0.0;
            }
        }
    }
    if(n == 2)
    {
        /* s = H[m-1][m-1] + H[n-1][n-1];
        t = H[m-1][m-1]*H[n-1][n-1] - H[m-1][n-1]*H[n-1][m-1];
        vector<vector<double>> M = mat_mult(H, H);
        temp = H;
        for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) temp[i][j] *= s;
        M = mat_minus(M, temp);
        temp1 = identity_mat(n);
        for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) temp1[i][j] *= t;
        M = mat_plus(M, temp1); */
        double tan = (H[1][1]-H[0][0] + sqrt(pow(H[1][1]-H[0][0], 2) + 4*H[0][1]*H[1][0]))/(-2*H[0][1]);
        double cos = sqrt(1/(pow(tan, 2) + 1)), sin = sqrt(pow(tan, 2)/(pow(tan, 2) + 1));
        P = {{cos, sin}, {-sin, cos}};
        H = mat_mult(transpose(P), H);
        H = mat_mult(H, P);
        if(abs(H[1][0]) < u) H[1][0] = 0.0;
    }
    return P;
}

int irreducible_uppper_Hessenberg(const vector<vector<double>> &H)  //不可约上Hessenberg
{
    int n = H.size();
    for(int i = 0;i < n-1;i++)
    {
        if(H[i+1][i] == 0)
        {
            return 0;
        }
    }
    return 1;
}

int almost_upper_trimax(const vector<vector<double>> &H)  //拟上三角
{
    int n = H.size();
    for(int i = 0;i < n;i++)
    {
        if(i > 0 && H[i][i-1] != 0) return 0;
        if(i < n-1 && H[i+1][i] == 0)
        {
            continue;
        }
        else if(i < n-1 && H[i+1][i] != 0)
        {
            if(pow(H[i][i]+H[i+1][i+1], 2) < 4*(H[i][i]*H[i+1][i+1] - H[i][i+1]*H[i+1][i]))
            {
                i++;
            }
            else return 0;
        }
        else if(i == n-1) ;
    }
    return 1;
}

void convergence_determination(vector<vector<double>> &H, int &m, int &l)  //收敛性判断, m = 0, l = n初始值
{
    int n = H.size();
    double u = 1.0e-7;
    for(int i = 1;i < n;i++)  //置零
    {
        if(abs(H[i][i-1]) <= (abs(H[i][i]) + abs(H[i-1][i-1]))*u)
        {
            H[i][i-1] = 0.0;
        }
    }
    //判断拟上三角和不可约上Hessenberg
    for(int i = n-1;i > 0;i--)
    {
        if(H[i][i-1] == 0) m++;
        else if(H[i][i-1] != 0 and i >= 2 and H[i-1][i-2] == 0) 
        {
            if(pow(H[i-1][i-1]+H[i][i], 2) < 4*(H[i-1][i-1]*H[i][i] - H[i-1][i]*H[i][i-1]))
            {
                i--;
                m+=2;
            }
            else break;
        }
        else if(H[i][i-1] != 0 and i >= 2 and H[i-1][i-2] != 0) break;
        else if(H[i][i-1] != 0 and i < 2)
        {
            if(pow(H[i-1][i-1]+H[i][i], 2) < 4*(H[i-1][i-1]*H[i][i] - H[i-1][i]*H[i][i-1]))
            {
                i--;
                m+=2;
            }
            else break;
        }
    }
    if(m == n-1) m = n;
    if(m != n)
    {
        l = n-m-1;
        for(int i = n-m-1;i > 0;i--)
        {
            if(H[i][i-1] != 0)
            {
                l--;
            }
            else break;
        }
    }
    if(m == n) l = 0;
}

void implicit_qr(vector<vector<double>> &A)
{
    int n = A.size(), count = 0;
    int m = 0, l = n;
    vector<vector<double>> H22, H12, H23, P;
    upper_Hessenberg(A);
    convergence_determination(A, m, l);
    while(m != n)
    {
        H22 = mat_partition(A,l+1,n-m,l+1,n-m);
        P = double_step_displacement_qr(H22);
        for(int i = 0;i < H22.size();i++) for(int j = 0;j < H22[0].size();j++) A[l+i][l+j] = H22[i][j];
        if(l != 0)
        {
            H12 = mat_partition(A, 1, l, l+1, n-m);
            H12 = mat_mult(H12, P);
            for(int i = 0;i < H12.size();i++) for(int j = 0;j < H12[0].size();j++) A[i][l+j] = H12[i][j];
        }
        if(m != 0)
        {
            H23 = mat_partition(A, l+1, n-m, n-m+1, n);
            H23 = mat_mult(transpose(P), H23);
            for(int i = 0;i < H23.size();i++) for(int j = 0;j < H23[0].size();j++) A[l+i][n-m+j] = H23[i][j];
        }
        m = 0,l = n;
        convergence_determination(A, m, l);
        count++;
    }
    cout << count << " times iteration" << endl;
}

void cal_eigen(const vector<vector<double>> &A, double &a, double &b)
{
    a = 1.0/2*(A[0][0] + A[1][1]);
    b = 1.0/2*sqrt(4*(A[0][0]*A[1][1]-A[0][1]*A[1][0])-pow(A[0][0]+A[1][1], 2));
}

void eigenvalue(vector<vector<double>> &A)
{
    int n = A.size();
    double a, b;
    implicit_qr(A);
    for(int i = 0;i < n;i++)
    {
        if(i != n-1 and A[i+1][i] == 0)
        {
            cout << A[i][i] << endl;
        }
        else if(i != n-1 and A[i+1][i] != 0)
        {
            cal_eigen(mat_partition(A, i+1, i+2, i+1, i+2), a, b);
            i++;
            cout << a << "+i" << b << endl;
            cout << a << "-i" << b << endl;
        }
        else if(i == n-1)
        {
            cout << A[i][i] << endl;
        }
    }
}

double power_method(const vector<vector<double>> &A, int times)//times是最大迭代次数
{
    int n = A.size(), count = 0, posi = 1;
    vector<vector<double>> u = zeros_mat(n, 1), y = zeros_mat(n, 1);
    double mu0 = 0.0, mu1 = 0.0, Max;
    for(int i = 0;i < n;i++) u[i][0] = 1.0;
    auto start = chrono::steady_clock::now();
    do
    {
        Max = vec_norm_inf(y, posi);
        mu0 = y[posi-1][0];//前一次y的模最大分量
        y = mat_mult(A, u);//迭代一次
        //cout_mat(y);
        Max = vec_norm_inf(y, posi);
        mu1 = y[posi-1][0];//这一次y的模最大分量
        for(int i = 0;i < n;i++) u[i][0] = y[i][0]/mu1;
        //cout_mat(u);
        count++;//计数
        //cout << "mu1: " << mu1 <<endl;
        //cout << "mu0: " << mu0 <<endl;
        if(count > times) break;
    } while (abs(mu1 - mu0) > 1e-7);//分量之差很小的时候跳出循环
    auto end = chrono::steady_clock::now();
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << "seconds" << endl;  //时间
    cout << count << " times iteration" << endl;
    return mu1;
}

double find_largest_root(const vector<double> &a, int times)//a放系数(从左到右为次数升高顺序)，times放最大迭代次数
{
    int n = a.size();
    vector<vector<double>> C = zeros_mat(n, n);
    for(int i = 1;i < n;i++)
    {
        C[i][i-1] = 1;
        C[i][n-1] = -a[i];
    }
    C[0][n-1] = -a[0];
    //幂法
    return power_method(C, times);
}

double E_norm(vector<vector<double>> &A)
{
    int n = A.size();
    double sum = 0.0, diag = 0.0;
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            sum += pow(A[i][j], 2);
        }
        diag += pow(A[i][i], 2);
    }
    sum -= diag;
    return sqrt(sum);
}

double sgn(double x)//符号函数
{
    if(x < 0) return -1;
    else if(x == 0) return 0;
    else return 1;
}

void Jacobi_pq(vector<vector<double>> &A, vector<vector<double>> &J, int p, int q)//对A的p和q做jacobi
{
    double t1 = 0.0, t2 = 0.0, c = 1.0, s = 0.0;
    int n = A.size();
    //vector<vector<double>> B = A, J1 = J;
    vector<double> temp_p, temp_q, temp_jp, temp_jq;
    for(int i = 0;i < n;i++) 
    {
        temp_p.push_back(A[i][p-1]);temp_q.push_back(A[i][q-1]);
        temp_jp.push_back(J[i][p-1]);temp_jq.push_back(J[i][q-1]);
    }//存A和J的第p和q列
    if(A[p-1][q-1] == 0) cout << "apq = 0" << endl;
    else
    {
        t1 = (A[q-1][q-1] - A[p-1][p-1])/(2.0*A[p-1][q-1]);
        if(t1 == 0) t2 = 1.0;
        else t2 = sgn(t1)/(abs(t1) + sqrt(1 + pow(t1, 2)));
        c = 1.0/sqrt(1 + pow(t2, 2));
        s = t2*c;
        //jacobi作用在A上！！
        for(int i = 0;i < n;i++)
        {
            if(i != p-1 and i != q-1) 
            {
                A[i][p-1] = c*temp_p[i] - s*temp_q[i];
                A[p-1][i] = c*temp_p[i] - s*temp_q[i];
                A[i][q-1] = s*temp_p[i] + c*temp_q[i];
                A[q-1][i] = s*temp_p[i] + c*temp_q[i];
                J[i][p-1] = c*temp_jp[i] - s*temp_jq[i];
                J[i][q-1] = s*temp_jp[i] + c*temp_jq[i];
            }
            else
            {
                J[i][p-1] = c*temp_jp[i] - s*temp_jq[i];
                J[i][q-1] = s*temp_jp[i] + c*temp_jq[i];
            }
        }
        A[p-1][p-1] = c*c*temp_p[p-1] - 2*s*c*temp_q[p-1] + s*s*temp_q[q-1];
        A[q-1][q-1] = s*s*temp_p[p-1] + 2*s*c*temp_q[p-1] + c*c*temp_q[q-1];
        A[p-1][q-1] = 0;
        A[q-1][p-1] = 0;
    }
}

void Pass_Jacobi(vector<vector<double>> &A, vector<vector<double>> &eigenvectors)
{
    int n = A.size(), flag = 0, count = 0;
    //确定关值
    double threshold = E_norm(A), sigma = n;  //sigma>=n是一个固定的常数，每次所有都过关后threshold/sigma作为新的threshold
    vector<vector<double>> J = identity_mat(n);
    auto start = chrono::steady_clock::now();
    while(threshold > 1e-10)
    {
        flag = 0;
        for(int i = 0;i < n-1;i++)
        {
            for(int j = i+1;j < n;j++)
            {
                if(abs(A[i][j]) > threshold)
                {
                    flag = 1;
                    Jacobi_pq(A, J, i+1, j+1);
                }
            }
        }
        if(flag == 0) threshold /= sigma;//更新关值
        count++;
    }
    auto end = chrono::steady_clock::now();
    eigenvectors = J;
    //cout << count << " times iteration" << endl;
    //cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
}

void quickSort(vector<double> &a, int low ,int high)
{
	if(low < high)  //判断是否满足排序条件，递归的终止条件
	{
		int i = low, j = high;   //把待排序数组元素的第一个和最后一个下标分别赋值给i,j，使用i,j进行排序；
		double x = a[low];    //将待排序数组的第一个元素作为哨兵，将数组划分为大于哨兵以及小于哨兵的两部分                                   
		while(i < j)  
		{
            while(i<j && a[j] >= x) j--;  //从最右侧元素开始，如果比哨兵大，那么它的位置就正确，然后判断前一个元素，直到不满足条件
		    if(i<j) a[i++] = a[j];   //把不满足位次条件的那个元素值赋值给第一个元素，（也即是哨兵元素，此时哨兵已经保存在x中，不会丢失）并把i的加1
		    while(i<j && a[i] <= x) i++; //换成左侧下标为i的元素开始与哨兵比较大小，比其小，那么它所处的位置就正确，然后判断后一个，直到不满足条件
		    if(i<j) a[j--] = a[i];  //把不满足位次条件的那个元素值赋值给下标为j的元素，（下标为j的元素已经保存到前面，不会丢失）并把j的加1
		} 
	    a[i] = x;   //完成一次排序，把哨兵赋值到下标为i的位置，即前面的都比它小，后面的都比它大
		quickSort(a, low ,i-1);  //递归进行哨兵前后两部分元素排序 ， low,high的值不发生变化，i处于中间
		quickSort(a, i+1 ,high);
	}
}

void eigen_of_tri_diag(vector<vector<double>> &A)
{
    int n = A.size();
    vector<vector<double>> eigenvectors = identity_mat(n);//, A1 = A;
    vector<double> a;
    Pass_Jacobi(A, eigenvectors);
    for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) if(abs(A[i][j]) < 1e-7) A[i][j] = 0;
    cout << "eigenvalues of A: " << endl;
    cout_mat(A);
    cout << "ascending order of eigenvalues: " << endl;
    for(int i = 0;i < n;i++) a.push_back(A[i][i]);
    quickSort(a, 0, n-1);
    for(int i = 0;i < n;i++) cout << a[i] << " ";
    cout << endl << endl;
    cout << "eigenvectors of A: " << endl;
    cout_mat(eigenvectors);
    //用来测试特征向量的。。。
    //vector<vector<double>> t = zeros_mat(n, 1),t1 = zeros_mat(n, 1);
    //for(int i = 0;i < n;i++) t[i][0] = eigenvectors[i][0], t1[i][0] = 2.00379*eigenvectors[i][0];
    //cout << vec_norm_2(mat_mult(A1, t), t1);
}

int number_of_sign_change(const vector<vector<double>> &T, double mu)//T是实对称三对角
{
    int n = T.size(), s = 0;
    vector<double> x, y;
    for(int i = 0;i < n;i++)
    {
        x.push_back(T[i][i]);
        if(i == 0) y.push_back(0);
        else y.push_back(T[i-1][i]);
    }
    double q = x[0] - mu, u = 1e-7;
    for(int k = 0;k < n;k++)
    {
        if(q < 0) s++;
        if(k < n-1)
        {
            if(q == 0) q = abs(y[k+1])*u;
            q = x[k+1] - mu - pow(y[k+1], 2)/q;
        }
    }
    return s;
}

double dichotomy(const vector<vector<double>> &T, int m)//矩阵T的第m个特征值
{
    int n = T.size(), count = 0, s = 0;
    double l = -mat_norm_inf(T), u = mat_norm_inf(T), eps = 1e-7;
    double r = (l + u)/2.0;
    auto start = chrono::steady_clock::now();
    while((u-l) > eps)
    {
        s = number_of_sign_change(T, r);
        if(s >= m) u = r;
        else l = r;
        r = (l + u)/2.0;
        count++;
    }
    auto end = chrono::steady_clock::now();
    cout << "dichotomy: " << count << " times iteration" << endl;
    cout << "take " << chrono::duration_cast<chrono::duration<double>>(end-start).count() << " seconds" << endl;  //时间
    return r;
}

vector<vector<double>> reverse_power_method(const vector<vector<double>> &T, double lambda)//lambda是特征值的近似值，
{
    int n = T.size(), count = 0;
    double zeta;
    vector<vector<double>> temp = identity_mat(n), M, z = zeros_mat(n, 1), v = zeros_mat(n, 1), L, U;
    for(int i = 0;i < n;i++) {temp[i][i] *= lambda;z[i][0] = 1.0;}
    M = mat_minus(T, temp);
    LU_Decomposition(M);
    L = get_L(M);
    U = get_U(M);
    while(count < 5)
    {
        for_subs(L, z);
        back_subs(U, z);
        zeta = vec_norm_2(z, v);
        for(int i = 0;i < n;i++) z[i][0] /= zeta;
        count++;
    }
    return z;
}

void dichotomy_and_reverse_power(const vector<vector<double>> &T)
{
    int n = T.size();
    double lambda1 = dichotomy(T, 1);
    vector<vector<double>> x1 = reverse_power_method(T, lambda1);
    cout << "the smallest eigenvalue:" << lambda1 << endl;
    cout << "eigenvector:" << endl;
    cout_mat(x1);
    cout << endl;
    double lambda2 = dichotomy(T, n);
    vector<vector<double>> x2 = reverse_power_method(T, lambda2);
    cout << "the largest eigenvalue:" << lambda2 << endl;
    cout << "eigenvector:" << endl;
    cout_mat(x2);
    cout << endl;
}

void bi_diag(vector<vector<double>> &A, vector<vector<double>> &U, vector<vector<double>> &V)//m>=n,U是mxm,V是nxn,传单位阵进来
{
    int m = A.size(), n = A[0].size();
    double beta = 0.0;
    vector<vector<double>> u, v, temp, temp1;
    vector<vector<double>> U1 = identity_mat(m), V1 = identity_mat(n);
    for(int k = 1;k < n+1;k++)
    {
        temp = mat_partition(A, k, m, k, k);
        v = zeros_mat(m-k+1, 1);
        Householder(temp, v, beta);
        temp1 = mat_partition(A,k,m,k,n);
        temp = House_mat(v,beta);
        temp1 = mat_mult(temp, temp1);
        for(int i = k-1;i < m;i++) for(int j = k-1;j < n;j++) A[i][j] = temp1[i-k+1][j-k+1];
        //for(int i = k;i < m;i++) A[i][k-1] = v[i-k+1][0];
        for(int i = k-1;i < m;i++) for(int j = k-1;j < m;j++) U1[i][j] = temp[i-k+1][j-k+1];
        U = mat_mult(U1, U);
        U1 = identity_mat(m);
        if(k < n-1)
        {
            temp = transpose(mat_partition(A,k,k,k+1,n));
            v = zeros_mat(n-k,1);
            Householder(temp,v,beta);
            temp1 = mat_partition(A,k,m,k+1,n);
            temp = House_mat(v,beta);
            temp1 = mat_mult(temp1, temp);
            for(int i = k-1;i < m;i++) for(int j = k;j < n;j++) A[i][j] = temp1[i-k+1][j-k];
            //for(int i = k+1;i < n;i++) A[k-1][i] = v[i-k][0];
            for(int i = k;i < n;i++) for(int j = k;j < n;j++) V1[i][j] = temp[i-k][j-k];
            V = mat_mult(V, V1);
            V1 = identity_mat(n);
        }
    }
    for(int i = 0;i < m;i++) for(int j = 0;j < n;j++) if(abs(A[i][j]) < 1e-7) A[i][j] = 0;
}

void wilkinson_SVD(vector<vector<double>> &B, vector<vector<double>> &P, vector<vector<double>> &Q)//给进去一个二对角B,对角线是delta，次对角线是gamma
{
    int n = B[0].size();
    double temp = 0, c = 0, s = 0;
    P = identity_mat(n);
    Q = identity_mat(n);
    vector<vector<double>> B_ = zeros_mat(2, 2);
    vector<vector<double>> J;
    vector<double> delta, gamma, temp_Qk(n,0), temp_Qk1(n,0), temp_Pk(n,0), temp_Pk1(n,0);//放P和Q的k\k+1行(列)
    delta.push_back(B[0][0]);
    for(int i = 1;i < n;i++) 
    {
        delta.push_back(B[i][i]);
        gamma.push_back(B[i-1][i]);
    }
    if(n > 2)
    {
        double alpha = pow(delta[n-1], 2) + pow(gamma[n-2], 2), Delta = (pow(delta[n-2], 2) + pow(gamma[n-3], 2) - alpha)/2.0, beta = \
        delta[n-2]*gamma[n-2];
        double mu = alpha - pow(beta, 2)/(Delta + sgn(Delta)*sqrt(pow(Delta, 2) + pow(beta, 2)));
        double y = pow(delta[0], 2) - mu, z = delta[0]*gamma[0], c = 0, s = 0;
        for(int k = 1;k < n;k++)
        {
            //Q:
            c = -y/(sqrt(pow(y, 2) + pow(z, 2)));
            s = z/(sqrt(pow(y, 2) + pow(z, 2)));
            //if(k > 1) gamma[k-2] = c*y - s*z;
            //记录Q
            for(int i = 0;i < n;i++) {temp_Qk[i] = Q[i][k-1];temp_Qk1[i] = Q[i][k];} //Q的第k,k+1列
            for(int i = 0;i < n;i++)
            {
                Q[i][k-1] = c*temp_Qk[i] - s*temp_Qk1[i];
                Q[i][k] = s*temp_Qk[i] + c*temp_Qk1[i];
            }
            //Q右作用一下
            if(k > 1)
            {
                gamma[k-2] = c*y - s*z;
                B[k-2][k] = 0;
                B[k-2][k-1] = gamma[k-2];
            }
            y = c*delta[k-1] - s*gamma[k-1];
            z = -s*delta[k];
            gamma[k-1] = s*delta[k-1] + c*gamma[k-1];
            delta[k] *= c;
            B[k-1][k-1] = y;B[k-1][k] = gamma[k-1];B[k][k-1] = z;B[k][k] = delta[k];
            //P:
            c = -y/(sqrt(pow(y, 2) + pow(z, 2)));
            s = z/(sqrt(pow(y, 2) + pow(z, 2)));
            //delta[k-1] = c*y - s*z;
            //记录P
            for(int i = 0;i < n;i++) {temp_Pk[i] = P[k-1][i];temp_Pk1[i] = P[k][i];} //P的第k,k+1行
            for(int i = 0;i < n;i++)
            {
                P[k-1][i] = c*temp_Pk[i] - s*temp_Pk1[i];
                P[k][i] = s*temp_Pk[i] + c*temp_Pk1[i];
            }
            //P左作用一下
            if(k < n-1)
            {
                delta[k-1] = c*y - s*z;
                y = c*gamma[k-1] - s*delta[k];
                z = -s*gamma[k];
                delta[k] = s*gamma[k-1] + c*delta[k];
                gamma[k] *= c;
                B[k-1][k] = y;B[k-1][k+1] = z;B[k][k] = delta[k];B[k][k+1] = gamma[k];B[k][k-1] = 0;B[k-1][k-1] = delta[k-1];
            }
            else
            {
                temp = gamma[k-1];//不设temp的话给gamma赋值的时候就修改了gamma，这样再赋值delta就不对了
                gamma[k-1] = c*temp - s*delta[k];
                delta[k] = s*temp + c*delta[k];
                delta[k-1] = c*y - s*z;
                B[k-1][k] = gamma[k-1];B[k][k] = delta[k];
                B[k-1][k-1] = delta[k-1];
                B[k][k-1] = 0;
            }
        }
    }
    else
    {
        c = (B[0][0] + B[1][1])/sqrt(pow((B[0][0] + B[1][1]), 2) + pow((B[1][0] - B[0][1]), 2));
        s = (B[1][0] - B[0][1])/sqrt(pow((B[0][0] + B[1][1]), 2) + pow((B[1][0] - B[0][1]), 2));
        B_[0][0] = c*B[0][0] + s*B[1][0];
        B_[0][1] = c*B[0][1] + s*B[1][1];
        B_[1][0] = -s*B[0][0] + c*B[1][0];
        B_[1][1] = -s*B[0][1] + c*B[1][1];
        Pass_Jacobi(B_, J);
        P[0][0] = sgn(B_[0][0])*(c*J[0][0] - s*J[1][0]);
        P[0][1] = sgn(B_[1][1])*(c*J[0][1] - s*J[1][1]);
        P[1][0] = sgn(B_[0][0])*(s*J[0][0] + c*J[1][0]);
        P[1][1] = sgn(B_[1][1])*(s*J[0][1] + c*J[1][1]);
        Q = J;//疑似？？
        B[0][0] = abs(B_[0][0]);B[0][1] = 0;B[1][0] = 0;B[1][1] = abs(B_[1][1]);
    }
}

void convergence_svd(vector<vector<double>> &A, int &p, int &q)//p=n,q=0传进去
{
    int n = A[0].size();
    double epsilon = 1e-7;
    //置零
    for(int i = 0;i < n-1;i++)
    {
        if(abs(A[i][i+1]) <= epsilon*(abs(A[i][i]) + abs(A[i+1][i+1]))) A[i][i+1] = 0;
        if(abs(A[i][i]) <= mat_norm_inf(A)*epsilon) A[i][i] = 0;
    }
    for(int i = n-1;i > 0;i--)
    {
        if (A[i-1][i] == 0)
        {
            q++;
            //cout << q << endl;
        }
        else break;
    }
    if(q == n-1) 
    {
        q++;
        p = 0;
    }
    else
    {
        int m = 0;
        while(A[n-q-m-2][n-q-m-1] != 0)
        {
            m++;
            if(m == n-q-1) break;
        }
        m++;
        p = n-q-m;
    }
}

void B_2_2(vector<vector<double>> &B, vector<vector<double>> &G, int k)//G存储givens变换,j是对角0的位置
{
    int n = B.size(), j = k;
    G = identity_mat(n);
    double c = 0, s = 0, B_tempj = 0, B_tempj1 = 0;//放B[j][j+1]和B[j+1][j+1]
    vector<double> row_gj(n, 0), row_gj1(n, 0);//记录G的j行和j+1行
    while(j < n-1)
    {
        B_tempj = B[j][j+1];
        B_tempj1 = B[j+1][j+1];
        //确定givens变换
        c = -B[j+1][j+1]/sqrt(pow(B[j][j+1], 2) + pow(B[j+1][j+1], 2));
        s = B[j][j+1]/sqrt(pow(B[j][j+1], 2) + pow(B[j+1][j+1], 2));
        //改变B
        B[j][j+1] = 0;
        B[j+1][j+1] = -s*B_tempj + c*B_tempj1;
        if(j < n-2) {B[j+1][j+2] *= s;B[j+2][j+2] *= c;}
        //累积G
        for(int i = 0;i < n;i++) {row_gj[i] = G[j][i];row_gj1[i] = G[j+1][i];}
        for(int i = 0;i < n;i++)
        {
            G[j][i] = c*row_gj[i] + s*row_gj1[i];
            G[j+1][i] = -s*row_gj[i] + c*row_gj1[i];
        }
        j++;
    }
}

void ep_eq_et(double &ep, double &eq, double &et, const vector<vector<double>> &U, const vector<vector<double>> &V, const vector<vector<double>> &A, const vector<vector<double>> &A1)
{
    int m = U.size(), n = V.size();
    vector<vector<double>> Ep, Eq, Et;
    Ep = mat_mult(U, transpose(U));
    Ep = mat_minus(Ep, identity_mat(m));
    ep = abs(Ep[0][0]);
    for(int i = 0;i < m;i++)
    {
        for(int j = 0;j < m;j++)
        {
            if(ep < abs(Ep[i][j])) ep = abs(Ep[i][j]);
        }
    } 
    cout << "ep = " << ep << endl;
    Eq = mat_mult(V, transpose(V));
    Eq = mat_minus(Eq, identity_mat(n));
    eq = abs(Eq[0][0]);
    for(int i = 0;i < n;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(eq < abs(Eq[i][j])) eq = abs(Eq[i][j]);
        }
    } 
    cout << "eq = " << eq << endl;
    Et = mat_minus(mat_mult(mat_mult(U,A1), V), A);
    et = abs(Et[0][0]);
    for(int i = 0;i < m;i++)
    {
        for(int j = 0;j < n;j++)
        {
            if(et < abs(Et[i][j])) et = abs(Et[i][j]);
        }
    } 
    cout << "et = " << et << endl;
}

void SVD(vector<vector<double>> &A)
{
    double ep, eq, et;
    vector<vector<double>> A1, sgn_mat;
    A1 = A;
    int m = A.size(), n = A[0].size(), count = 0;
    int p = n, q = 0, flag = 1;
    vector<vector<double>> U = identity_mat(m), V = identity_mat(n), U_temp = identity_mat(m), V_temp = identity_mat(n), G_temp = identity_mat(m);
    vector<vector<double>> B22, G, P, Q;
    //二对角化
    bi_diag(A, U, V);
    vector<vector<double>> B = mat_partition(A,1,n,1,n);
    //收敛性判断
    while(flag)
    {
        p = n;q = 0;
        convergence_svd(B, p, q);
        //cout << "p: " <<p << endl;
        //cout << "q: " <<q << endl;
        //cout_mat(B);
        if(q == n)
        {
            cout << "over" << endl;//之后再弄输出
            for(int i = 0;i < n;i++) for(int j = 0;j < n;j++) A[i][j] = B[i][j];
            //还要手动改一下，因为这样算出来奇异值有负的
            sgn_mat = identity_mat(m);
            for(int i = 0;i < n;i++) if(i != 2 and i != 3) sgn_mat[i][i] = -1;
            A = mat_mult(sgn_mat, A);
            U = mat_mult(U, sgn_mat);
            cout_mat(A);
            cout_mat(U);
            cout_mat(V);
            ep_eq_et(ep, eq, et, U, V, A, A1);
            flag = 0;
        }
        else
        {
            //checkB22的对角元
            for(int i = 0;i < n-p-q;i++) 
            {
                if(B[i+p][i+p] == 0 and i != n-p-q-1) //有对角元为0，把他变成两个二对角
                {
                    //cout << "now check B22 diag" << endl;
                    B22 = mat_partition(B,p+1,n-q,p+1,n-q);
                    B_2_2(B22, G, i+p);
                    for(int i = 0;i < n-p-q;i++) for(int j = 0;j < n-p-q;j++) B[i+p][j+p] = B22[i][j];
                    //还要把G作用到U上
                    for(int i = 0;i < n-p-q;i++) for(int j = 0;j < n-p-q;j++) G_temp[i+p][j+p] = G[i][j]; 
                    U = mat_mult(G_temp, U);
                    G_temp = identity_mat(m);
                    flag = 0;
                    break;
                }
            }
            if(flag)
            {
                //cout << "B22 no diag = 0" << endl;
                B22 = mat_partition(B,p+1,n-q,p+1,n-q);
                wilkinson_SVD(B22, P, Q);
                for(int i = 0;i < n-p-q;i++) for(int j = 0;j < n-p-q;j++) B[i+p][j+p] = B22[i][j];
                for(int i = 0;i < n-p-q;i++) for(int j = 0;j < n-p-q;j++) U_temp[i+p][j+p] = P[i][j];
                for(int i = 0;i < n-p-q;i++) for(int j = 0;j < n-p-q;j++) V_temp[i+p][j+p] = Q[i][j];
                U = mat_mult(U_temp, U);//疑似？？
                V = mat_mult(V, V_temp);
                U_temp = identity_mat(m);
                V_temp = identity_mat(n);
            }
            else
            {
                cout << "B22 has 0-diag" << endl;
                flag = 1;
                //cout_mat(B);
            }
        }
    }
}

//以上是旧时代的残党


void scalar_times_mat(const double &a, vector<vector<double>> &A)
{
    int m = A.size(), n = A[0].size();
    for(int i = 0;i < m;i++) for(int j = 0;j < n;j++) A[i][j] *= a;
}

double three_hump_camel(const double &x1, const double &x2)//THREE-HUMP CAMEL FUNCTION
{
    return 2*x1*x1-1.05*pow(x1,4)+pow(x1,6)/6.0+x1*x2+x2*x2;
}

double f2(const double &x1, const double &x2)  //Rosenbrock function
{
    return 100*(x2-x1*x1)*(x2-x1*x1) + pow((1-x1), 2);
}

double f3(const double &x1, const double &x2, const double &x3)  //Rosenbrock function
{
    return 100*(x2-x1*x1)*(x2-x1*x1) + pow((1-x1), 2)+100*(x3-x2*x2)*(x3-x2*x2) + pow((1-x2), 2);
}

double f4(const double &x1, const double &x2, const double &x3, const double &x4)  //Rosenbrock function
{
    return 100*(x2-x1*x1)*(x2-x1*x1) + pow((1-x1), 2)+100*(x3-x2*x2)*(x3-x2*x2) + pow((1-x2), 2)+\
    100*(x4-x3*x3)*(x4-x3*x3) + pow((1-x3), 2);
}

double f5(const double &x1, const double &x2, const double &x3, const double &x4, const double &x5)  //Rosenbrock function
{
    return 100*(x2-x1*x1)*(x2-x1*x1) + pow((1-x1), 2)+100*(x3-x2*x2)*(x3-x2*x2) + pow((1-x2), 2)+\
    100*(x4-x3*x3)*(x4-x3*x3) + pow((1-x3), 2)+100*(x5-x4*x4)*(x5-x4*x4) + pow((1-x4), 2);
}

vector<vector<double>> gradf(const double &x1, const double &x2)//gradient of three-hump camel function
{
    double gradf_1 = 4*x1 - 4.2*pow(x1,3)+pow(x1,5)+x2;
    double gradf_2 = x1+2*x2;
    vector<vector<double>> result = {{gradf_1}, {gradf_2}};
    return result;
}

vector<vector<double>> gradf2(const double &x1, const double &x2)  //gradient of f2
{
    double gradf_1 =  400*x1*x1*x1 - 400*x1*x2 + 2*(x1 - 1);
    double gradf_2 = 200*(x2 - x1*x1);
    vector<vector<double>> result = {{gradf_1}, {gradf_2}};
    return result;
}

vector<vector<double>> gradf3(const double &x1, const double &x2, const double &x3)  //gradient of f3
{
    double gradf_1 = 400*x1*x1*x1 - 400*x1*x2 + 2*(x1 - 1);
    double gradf_2 = 200*(x2 - x1*x1) + 400*x2*x2*x2 - 400*x2*x3 + 2*(x2 - 1);
    double gradf_3 = 200*(x3 - x2*x2);
    vector<vector<double>> result = {{gradf_1}, {gradf_2}, {gradf_3}};
    return result;
}

vector<vector<double>> gradf4(const double &x1, const double &x2, const double &x3, const double &x4)  //gradient of f4
{
    double gradf_1 = 400*x1*x1*x1 - 400*x1*x2 + 2*(x1 - 1);
    double gradf_2 = 200*(x2 - x1*x1) + 400*x2*x2*x2 - 400*x2*x3 + 2*(x2 - 1);
    double gradf_3 = 200*(x3 - x2*x2) + 400*x3*x3*x3 - 400*x3*x4 + 2*(x3 - 1);
    double gradf_4 = 200*(x4 - x3*x3);
    vector<vector<double>> result = {{gradf_1}, {gradf_2}, {gradf_3}, {gradf_4}};
    return result;
}

vector<vector<double>> gradf5(const double &x1, const double &x2, const double &x3, const double &x4, const double &x5)  //gradient of f5
{
    double gradf_1 = 400*x1*x1*x1 - 400*x1*x2 + 2*(x1 - 1);
    double gradf_2 = 200*(x2 - x1*x1) + 400*x2*x2*x2 - 400*x2*x3 + 2*(x2 - 1);
    double gradf_3 = 200*(x3 - x2*x2) + 400*x3*x3*x3 - 400*x3*x4 + 2*(x3 - 1);
    double gradf_4 = 200*(x4 - x3*x3) + 400*x4*x4*x4 - 400*x4*x5 + 2*(x4 - 1);
    double gradf_5 = 200*(x5 - x4*x4);
    vector<vector<double>> result = {{gradf_1}, {gradf_2}, {gradf_3}, {gradf_4}, {gradf_5}};
    return result;
}

double phi(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)  //phi(alpha) = f(x+alpha*d)
{
    int n = x.size();
    switch (n)
    {
    case 2:
        return f2(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0]);
    case 3:
        return f3(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0]);
    case 4:
        return f4(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0], x[3][0] + alpha*d[3][0]);
    case 5:
        return f5(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0], x[3][0] + alpha*d[3][0], x[4][0] + alpha*d[4][0]);
    default :
        return 0;
    }
}

double phi_(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)  //phi'
{
    vector<vector<double>> result;
    int n = x.size();
    switch (n)
    {
    case 2:
        result = mat_mult(transpose(gradf2(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0])), d);
        break;
    case 3:
        result = mat_mult(transpose(gradf3(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0])), d);
        break;
    case 4:
        result = mat_mult(transpose(gradf4(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0], x[3][0] + alpha*d[3][0])), d);
        break;
    case 5:
        result = mat_mult(transpose(gradf5(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0], x[2][0] + alpha*d[2][0], x[3][0] + alpha*d[3][0], x[4][0] + alpha*d[4][0])), d);
        break;
    }
    return result[0][0];
}

double phif(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    return three_hump_camel(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0]);
}

double phi_f(const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    vector<vector<double>> result;
    result = mat_mult(transpose(gradf(x[0][0] + alpha*d[0][0], x[1][0] + alpha*d[1][0])), d);
    return result[0][0];
}

double wolfe_powell_find_alpha(const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    //initializing
    int count = 0;
    double alpha_bar = 1.0, rho = 0.25, sigma = 0.5;
    double phi0 = phi(0, x, d), phi_0 = phi_(0, x, d);//phi(0)和phi'(0)
    double a1 = 0, a2 = alpha_bar;
    double alpha = (a1 + a2)/2.0, alpha_hat, phi_value, phi_derivative;
    //Step1
    while(count < 1000)
    {
        phi_value = phi(alpha, x, d);
        if(phi_value <= (phi0 + rho*alpha*phi_0))
        {
            //Step2
            phi_derivative = phi_(alpha, x, d);//phi'(alpha)
            if(phi_derivative >= sigma*phi_0) break;
            else
            {
                if((phi_0 - phi_derivative) < 1e-32) break;
                alpha_hat = alpha - ((a1 - alpha)*phi_derivative)/(phi_0 - phi_derivative);
                a1 = alpha;
                alpha = alpha_hat;
                phi0 = phi_value;
                phi_0 = phi_derivative;
            }
        }
        else
        {
            alpha_hat = a1 + 0.5*((a1-alpha)*(a1-alpha)*phi_0)/(phi0 - phi_value - (a1 - alpha)*phi_0);
            a2 = alpha;
            alpha = alpha_hat;
        }
        count++;
    }
    return alpha;
}

double wolfe_powell_find_alpha_f(const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    //initializing
    int count = 0;
    double alpha_bar = 1.0, rho = 0.25, sigma = 0.5;
    double phi0 = phif(0, x, d), phi_0 = phi_f(0, x, d);//phi(0)和phi'(0)
    double a1 = 0, a2 = alpha_bar;
    double alpha = (a1 + a2)/2.0, alpha_hat, phi_value, phi_derivative;
    //Step1
    while(count < 1000)
    {
        phi_value = phif(alpha, x, d);
        if(phi_value <= (phi0 + rho*alpha*phi_0))
        {
            //Step2
            phi_derivative = phi_f(alpha, x, d);//phi'(alpha)
            if(phi_derivative >= sigma*phi_0) break;
            else
            {
                if((phi_0 - phi_derivative) < 1e-32) break;
                alpha_hat = alpha - ((a1 - alpha)*phi_derivative)/(phi_0 - phi_derivative);
                a1 = alpha;
                alpha = alpha_hat;
                phi0 = phi_value;
                phi_0 = phi_derivative;
            }
        }
        else
        {
            alpha_hat = a1 + 0.5*((a1-alpha)*(a1-alpha)*phi_0)/(phi0 - phi_value - (a1 - alpha)*phi_0);
            a2 = alpha;
            alpha = alpha_hat;
        }
        count++;
    }
    return alpha;
}

void DFP(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)//传Hk进去变成H_k+1
{
    int n = x.size();
    vector<vector<double>> s = d;
    scalar_times_mat(alpha, s);
    vector<vector<double>> x_ = mat_plus(x, s);//x_k+1 = x_k + alpha*d
    vector<vector<double>> y;
    switch (n)
    {
    case 2:
        y = mat_minus(gradf2(x_[0][0], x_[1][0]), gradf2(x[0][0], x[1][0]));
        break;
    case 3:
        y = mat_minus(gradf3(x_[0][0], x_[1][0], x_[2][0]), gradf3(x[0][0], x[1][0], x[2][0]));
        break;
    case 4:
        y = mat_minus(gradf4(x_[0][0], x_[1][0], x_[2][0], x_[3][0]), gradf4(x[0][0], x[1][0], x[2][0], x[3][0]));
        break;
    case 5:
        y = mat_minus(gradf5(x_[0][0], x_[1][0], x_[2][0], x_[3][0], x_[4][0]), gradf5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]));
        break;
    
    }
    vector<vector<double>> ss_T = mat_mult(s, transpose(s)), yy_T = mat_mult(y, transpose(y)), temp1 = mat_mult(transpose(s), y), \
    temp2 = mat_mult(transpose(y), mat_mult(H, y));
    double sy = temp1[0][0], yHy = temp2[0][0];
    scalar_times_mat(1.0/sy, ss_T);
    yy_T = mat_mult(mat_mult(H,yy_T), H);
    scalar_times_mat(-1.0/yHy, yy_T);
    H = mat_plus(mat_plus(H, ss_T), yy_T);
}

void DFP_f(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    vector<vector<double>> s = d;
    scalar_times_mat(alpha, s);
    vector<vector<double>> x_ = mat_plus(x, s);//x_k+1 = x_k + alpha*d
    vector<vector<double>> y = mat_minus(gradf(x_[0][0], x_[1][0]), gradf(x[0][0], x[1][0]));
    vector<vector<double>> ss_T = mat_mult(s, transpose(s)), yy_T = mat_mult(y, transpose(y)), temp1 = mat_mult(transpose(s), y), \
    temp2 = mat_mult(transpose(y), mat_mult(H, y));
    double sy = temp1[0][0], yHy = temp2[0][0];
    scalar_times_mat(1.0/sy, ss_T);
    yy_T = mat_mult(mat_mult(H,yy_T), H);
    scalar_times_mat(-1.0/yHy, yy_T);
    H = mat_plus(mat_plus(H, ss_T), yy_T);
}

void BFGS(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    int n = x.size();
    vector<vector<double>> s = d;
    scalar_times_mat(alpha, s);
    vector<vector<double>> x_ = mat_plus(x, s);//x_k+1 = x_k + alpha*d
    vector<vector<double>> y;
    switch (n)
    {
    case 2:
        y = mat_minus(gradf2(x_[0][0], x_[1][0]), gradf2(x[0][0], x[1][0]));
        break;
    case 3:
        y = mat_minus(gradf3(x_[0][0], x_[1][0], x_[2][0]), gradf3(x[0][0], x[1][0], x[2][0]));
        break;
    case 4:
        y = mat_minus(gradf4(x_[0][0], x_[1][0], x_[2][0], x_[3][0]), gradf4(x[0][0], x[1][0], x[2][0], x[3][0]));
        break;
    case 5:
        y = mat_minus(gradf5(x_[0][0], x_[1][0], x_[2][0], x_[3][0], x_[4][0]), gradf5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]));
        break;
    
    }
    vector<vector<double>> ss_T = mat_mult(s, transpose(s)), Hys_T = mat_mult(mat_mult(H, y), transpose(s)), sy_TH = mat_mult(mat_mult(s, transpose(y)), H), \
    temp1 = mat_mult(transpose(s), y),temp2 = mat_mult(transpose(y), mat_mult(H, y));
    vector<vector<double>> sum = mat_plus(Hys_T, sy_TH);
    double coef1 = (1.0 + temp2[0][0]/temp1[0][0])/temp1[0][0], coef2 = -1.0/temp1[0][0];
    scalar_times_mat(coef1, ss_T);
    scalar_times_mat(coef2, sum);
    H = mat_plus(mat_plus(H, ss_T), sum);
}

void BFGS_f(vector<vector<double>> &H, const double &alpha, const vector<vector<double>> &x, const vector<vector<double>> &d)
{
    vector<vector<double>> s = d;
    scalar_times_mat(alpha, s);
    vector<vector<double>> x_ = mat_plus(x, s);//x_k+1 = x_k + alpha*d
    vector<vector<double>> y = mat_minus(gradf(x_[0][0], x_[1][0]), gradf(x[0][0], x[1][0]));
    vector<vector<double>> ss_T = mat_mult(s, transpose(s)), Hys_T = mat_mult(mat_mult(H, y), transpose(s)), sy_TH = mat_mult(mat_mult(s, transpose(y)), H), \
    temp1 = mat_mult(transpose(s), y),temp2 = mat_mult(transpose(y), mat_mult(H, y));
    vector<vector<double>> sum = mat_plus(Hys_T, sy_TH);
    double coef1 = (1.0 + temp2[0][0]/temp1[0][0])/temp1[0][0], coef2 = -1.0/temp1[0][0];
    scalar_times_mat(coef1, ss_T);
    scalar_times_mat(coef2, sum);
    H = mat_plus(mat_plus(H, ss_T), sum);
}

void wolfe_powell_quasi_newton(int choice, int n)//n是函数f的维数,2 <= n <= 5
{
    //initializing
    int count = 0;
    vector<vector<double>> x;
    double x1, x2, x3, x4, x5;
    cout << "input the initial point: " << endl;
    switch (n)//输入初始点
    {
    case 2:
        cin >> x1 >> x2;
        x = {{x1}, {x2}};
        break;
    case 3:
        cin >> x1 >> x2 >> x3;
        x = {{x1}, {x2}, {x3}};
        break;
    case 4:
        cin >> x1 >> x2 >> x3 >> x4;
        x = {{x1}, {x2}, {x3}, {x4}};
        break;
    case 5:
        cin >> x1 >> x2 >> x3 >> x4 >> x5;
        x = {{x1}, {x2}, {x3}, {x4}, {x5}};
        break;
    }
    vector<vector<double>> d;
    double alpha;
    vector<vector<double>> H = identity_mat(n);
    //searching_direction
    switch (n)//算不同维数梯度
    {
    case 2:
        d = mat_mult(H, gradf2(x[0][0], x[1][0]));
        break;
    case 3:
        d = mat_mult(H, gradf3(x[0][0], x[1][0], x[2][0]));
        break;
    case 4:
        d = mat_mult(H, gradf4(x[0][0], x[1][0], x[2][0], x[3][0]));
        break;
    case 5:
        d = mat_mult(H, gradf5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]));
        break;
    }
    scalar_times_mat(-1, d);//负梯度方向
    if(choice == 1)//DFP
    {
        while(vec_norm_1(d) > 1e-10 and count < 10000)
        {
            //alpha
            alpha = wolfe_powell_find_alpha(x, d);
            //H_k+1
            DFP(H, alpha, x, d);
            //x_k+1
            scalar_times_mat(alpha, d);
            x = mat_plus(x, d);
            //d_k+1
            switch (n)
            {
            case 2:
                d = mat_mult(H, gradf2(x[0][0], x[1][0]));
                break;
            case 3:
                d = mat_mult(H, gradf3(x[0][0], x[1][0], x[2][0]));
                break;
            case 4:
                d = mat_mult(H, gradf4(x[0][0], x[1][0], x[2][0], x[3][0]));
                break;
            case 5:
                d = mat_mult(H, gradf5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]));
                break;
            }
            scalar_times_mat(-1, d);
            count++;
        }
        for(int i = 0;i < n;i++) cout << x[i][0] << " ";
        cout << endl;
        switch (n)
        {
        case 2:
            cout << "f(x) = " << f2(x[0][0], x[1][0]) << endl;
            break;
        case 3:
            cout << "f(x) = " << f3(x[0][0], x[1][0], x[2][0]) << endl;
            break;
        case 4:
            cout << "f(x) = " << f4(x[0][0], x[1][0], x[2][0], x[3][0]) << endl;
            break;
        case 5:
            cout << "f(x) = " << f5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]) << endl;
            break;
        }
        cout << count << " times iteration" << endl;
    }
    else if (choice == 2)//BFGS  好像这个厉害一点
    {
        while(vec_norm_1(d) > 1e-10 and count < 10000)
        {
            //alpha
            alpha = wolfe_powell_find_alpha(x, d);
            //H_k+1
            BFGS(H, alpha, x, d);
            //x_k+1
            scalar_times_mat(alpha, d);
            x = mat_plus(x, d);
            //d_k+1
            switch (n)
            {
            case 2:
                d = mat_mult(H, gradf2(x[0][0], x[1][0]));
                break;
            case 3:
                d = mat_mult(H, gradf3(x[0][0], x[1][0], x[2][0]));
                break;
            case 4:
                d = mat_mult(H, gradf4(x[0][0], x[1][0], x[2][0], x[3][0]));
                break;
            case 5:
                d = mat_mult(H, gradf5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]));
                break;
            }
            scalar_times_mat(-1, d);
            count++;
        }
        for(int i = 0;i < n;i++) cout << x[i][0] << " ";
        cout << endl;
        switch (n)
        {
        case 2:
            cout << "f(x) = " << f2(x[0][0], x[1][0]) << endl;
            break;
        case 3:
            cout << "f(x) = " << f3(x[0][0], x[1][0], x[2][0]) << endl;
            break;
        case 4:
            cout << "f(x) = " << f4(x[0][0], x[1][0], x[2][0], x[3][0]) << endl;
            break;
        case 5:
            cout << "f(x) = " << f5(x[0][0], x[1][0], x[2][0], x[3][0], x[4][0]) << endl;
            break;
        }
        cout << count << " times iteration" << endl;
    }
    else cout << "wrong!" << endl;
}

void wolfe_powell_quasi_newton_f(int choice)
{
    //initializing
    int count = 0;
    vector<vector<double>> x;
    double x1, x2;
    cout << "input the initial point: " << endl;
    cin >> x1 >> x2;
    x = {{x1}, {x2}};
    vector<vector<double>> d;
    double alpha;
    vector<vector<double>> H = identity_mat(2);
    //searching_direction
    d = mat_mult(H, gradf(x[0][0], x[1][0]));
    scalar_times_mat(-1, d);//负梯度方向
    if(choice == 1)//DFP
    {
        while(vec_norm_1(d) > 1e-10 and count < 10000)
        {
            //alpha
            alpha = wolfe_powell_find_alpha_f(x, d);
            //H_k+1
            DFP_f(H, alpha, x, d);
            //x_k+1
            scalar_times_mat(alpha, d);
            x = mat_plus(x, d);
            //d_k+1
            d = mat_mult(H, gradf(x[0][0], x[1][0]));
            scalar_times_mat(-1, d);
            count++;
        }
        cout << x[0][0] << " " << x[1][0] << endl;
        cout << "f(x) = " << three_hump_camel(x[0][0], x[1][0]) << endl;
        cout << count << " times iteration" << endl;
    }
    else if (choice == 2)//BFGS  好像这个厉害一点
    {
        while(vec_norm_1(d) > 1e-10 and count < 10000)
        {
            //alpha
            alpha = wolfe_powell_find_alpha_f(x, d);
            //H_k+1
            BFGS_f(H, alpha, x, d);
            //x_k+1
            scalar_times_mat(alpha, d);
            x = mat_plus(x, d);
            //d_k+1
            d = mat_mult(H, gradf(x[0][0], x[1][0]));
            scalar_times_mat(-1, d);
            count++;
        }
        cout << x[0][0] << " " << x[1][0] << endl;
        cout << "f(x) = " << three_hump_camel(x[0][0], x[1][0]) << endl;
        cout << count << " times iteration" << endl;
    }
    else cout << "wrong!" << endl;
}
