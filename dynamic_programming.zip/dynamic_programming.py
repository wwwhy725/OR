#  背包问题
class Bag():
    #  最朴素的01背包
    def bag(self, n, c, w, v):
        """
        :param n: number of goods
        :param c: capacity of the bag
        :param w: weight of each good
        :param v: value of each good
        :return: value
        """
        # initialize
        value = [[0 for j in range(c + 1)] for i in range(n + 1)]
        for i in range(1, n + 1):
            for j in range(1, c + 1):
                value[i][j] = value[i - 1][j]
                if j >= w[i - 1] and value[i][j] < value[i - 1][j - w[i - 1]] + v[i - 1]:
                    value[i][j] = value[i - 1][j - w[i - 1]] + v[i - 1]
        return value[n][c]

    #  分割等和子集 (判断是否可以分割成等和的两个子集) O(n*target)
    def canPartition(self, nums) -> bool:
        sumAll = sum(nums)
        if sumAll % 2:
            return False
        target = sumAll // 2
        dp = [False] * (target + 1)  #dp[j]表示是否有和为j的子集
        dp[0] = True
        for i in range(len(nums)):
            for j in range(target, nums[i] - 1, -1):
                dp[j] = dp[j] or dp[j - nums[i]]
        return dp[-1]

    #  零钱兑换I(可以凑成总金额的最少硬币个数)  O(n*amount)
    def coinChange1(self, coins, amount):
        # 初始化
        dp = [amount + 1] * (amount + 1)
        dp[0] = 0
        # 遍历物品
        for coin in coins:
            # 遍历背包
            for j in range(coin, amount + 1):
                dp[j] = min(dp[j], dp[j - coin] + 1)
        return dp[amount] if dp[amount] < amount + 1 else -1

    #  零钱兑换II(可以凑成总金额的硬币组合数)  O(n*amount)
    def coinChange2(self, coins, amount):
        dp = [1] + [0] * amount
        for coin in coins:
            for j in range(coin, amount + 1):
                dp[j] += dp[j - coin]
        return dp[-1]

    #  多重背包(二进制优化)
    def multBag(self, n, c, w, v, s):
        '''
        :param n: int; number of goods
        :param c: int; capacity
        :param w: int[]; weight of each good
        :param v: int[]; value of each good
        :param s: int[]; number of  each good
        :return:
        '''
        dp = [0] * (c + 1)
        for i in range(n):
            vi, wi, si = v[i], w[i], s[i]
            for j in range(wi):
                queue = []
                head, tail = 0, -1
                times = (c - j) // wi
                for k in range(times + 1):
                    curr = dp[k * wi + j] - k * vi
                    if head <= tail and queue[head][0] == k - si - 1:
                        head += 1
                    while head <= tail and queue[-1][1] < curr:
                        queue.pop()
                        tail -= 1
                    queue.append([k, curr])
                    tail += 1
                    dp[k * wi + j] = queue[head][1] + k * vi
        return dp[c]


#  子序列问题
class SubArray():
    def __init__(self, nums):
        self.nums = nums

    #  最大子序列 O(n)
    def maxSubArray(self):
        tmp_sum = 0
        result = nums[0]
        for num in self.nums:
            tmp_sum = max(tmp_sum + num, num)
            result = max(result, tmp_sum)
        return result

    #  最长(严格)递增子序列  O(nlogn)
    def lengthOfLIS(self):
        tails, result = [0] * len(self.nums), 0
        for num in self.nums:
            i, j = 0, result
            while i < j:
                m = (i + j) // 2
                if tails[m] < num:
                    i = m + 1  # 如果要求非严格递增，将此行 '<' 改为 '<=' 即可。
                else:
                    j = m
            tails[i] = num
            if j == result: result += 1
        return result


#  博弈
def optimalStrategyOfGame(nums):
    n = len(nums)
    dp = [[0 for i in range(n)] for i in range(n)]

    for gap in range(n):
        for j in range(gap, n):
            i = j - gap
            x = 0
            if (i + 2) <= j:
                x = dp[i + 2][j]
            y = 0
            if (i + 1) <= (j - 1):
                y = dp[i + 1][j - 1]
            z = 0
            if i <= (j - 2):
                z = dp[i][j - 2]
            dp[i][j] = max(nums[i] + min(x, y), nums[j] + min(y, z))
    return dp[0][n - 1]


if __name__ == '__main__':
    #  背包问题数据集
    n = 4
    '''
    c = 500
    w = [10, 20, 30, 40]
    v = [20, 40, 40, 50]
    s = [3, 1, 3, 2]
    结果为【1】: 150, 【5】: 320
    '''
    c = 5
    w = [1, 2, 3, 4]
    v = [2, 4, 4, 5]
    s = [3, 1, 3, 2]
    #  零钱问题数据集
    coins = [1, 2, 5]
    amount = 11
    #  子序列问题数据集
    nums = [-2, 1, -3, 4, -1, 2, 1, -5, 4]
    nums1 = [10, 9, 2, 5, 3, 7, 101, 18]
    #  博弈问题数据集
    arr1 = [20, 3, 2, 56, 2, 10, 17, 100]
    bag = Bag()
    subarray = SubArray(nums)
    flag = '1'
    while flag == '1':
        f = input("请输入需要测试的问题：\n【1】01背包问题\n【2】分割等和子集问题\n【3】零钱问题I(最少硬币个数)\n【4】零钱问题II("
                  "硬币组合数)\n【5】多重背包问题\n【6】子序列最大和\n【7】最长递增子序列\n【8】博弈问题\n")
        print("测试数据集为:")
        if f == '1':
            print("n = ", n)
            print("c = ", c)
            print("v = ", v)
            print("w = ", w)
            print("最大价值: ", bag.bag(n,c,w,v))
        if f == '2':
            print("nums = ", nums1)
            print("是否能分割成两个等和子集:", bag.canPartition(nums1))
        if f == '3':
            print("coins = ", coins)
            print("amount = ", amount)
            print("最少硬币个数:", bag.coinChange1(coins, amount))
        if f == '4':
            print("coins = ", coins)
            print("amount = ", amount)
            print("硬币组合数:", bag.coinChange2(coins, amount))
        if f == '5':
            print("n = ", n)
            print("c = ", c)
            print("v = ", v)
            print("w = ", w)
            print("s = ", s)
            print("最大价值: ", bag.multBag(n, c, w, v, s))
        if f == '6':
            print("nums = ", nums)
            print("连续子序列最大和:", subarray.maxSubArray())
        if f == '7':
            print("nums = ", nums)
            print("最长递增子列的长度:", subarray.lengthOfLIS())
        if f == '8':
            print("nums = ", arr1)
            print("能赢得的最大金额:", optimalStrategyOfGame(arr1))
        flag = input("是否接着测试？请输入1或0\n")


